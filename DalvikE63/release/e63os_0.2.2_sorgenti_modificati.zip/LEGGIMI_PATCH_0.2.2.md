# Sorgenti modificati per E63 UI 0.2.2 — 27 settembre 2026

Sovrascrivere i corrispondenti file in `DalvikE63/` della ZIP sorgenti 0.2.1 con questi file.
Il J2ME originale, `classes.dex`, APK, JAR/JAD e asset NON sono stati rigenerati.
Il patch introduce il tasto funzione sinistro come Back, il destro come Select,
servizi Java ME limitati per tasti negativi/Back e la correzione del D-pad.
Per il build ripetibile servono Nokia S60 FP1 SDK e le licenze applicabili: 
`tools/bootstrap_symbian_fp1.sh` / `tools/build_symbian_fp1.sh`.
NON lanciare il vecchio script della release completa: i SISX precedenti e
l'archivio sorgenti integrale restano volutamente conservati.
Non sono inclusi SDK Nokia, certificati privati, firmware o codice Android AOSP.
La 0.2.1 Home/Fn funziona sull'E63 dell'utente; input fisico 0.2.2 ancora da verificare.
